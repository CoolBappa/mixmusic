<?php
session_start();
include '../settings.php';
include '../'.$set->template.'/contact.tpl';
?> 