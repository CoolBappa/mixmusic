</div>
</div>
</div>
</div>
</div>
</div>
<div class="clear marginbot-10" style="height:20px"></div>
<div class="footer">
Admin Powered by WAPcms | Theme Created by WebNext<font color="#3399cc">Media</font>
</div>
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

</body>
</html>