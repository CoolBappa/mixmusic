<?php
$db_host = 'localhost';
$db_user = 'mixmusic_mixmusi';
$db_pass = 'St[=7y5_C]Eu';
$db_name = 'mixmusic_mixmusic';
?>
