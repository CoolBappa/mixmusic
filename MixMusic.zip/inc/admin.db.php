<?php
require_once 'inc/cacheClassadmin.php';
require_once 'inc/db.config.php';
$db = new database($db_host,$db_user,$db_pass,$db_name);
?>
