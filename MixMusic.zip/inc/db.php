<?php
require_once 'cacheClass.php';
require_once 'db.class.php';
require_once 'db.config.php';
$db = new database($db_host,$db_user,$db_pass,$db_name);
?>
